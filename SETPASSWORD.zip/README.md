# Set Password Extension

## Description
The Set Password extension allows users to set the password for their chrome. This is useful for whose friends disturb them and see there chrome for knowing what does the person is doing. I made this extension because of some of my friends which always comes and see what i am doing on my laptop and i know that except me there are alot which is disturb because of this that's why i have made this.

## Installation
To install the Set Password extension, follow these steps:

1. Clone the repo.
   ```
     git clone https://github.com/Gorav22/Set-Password
   ```
2. Go to chrome://extensions.
3. Make the toggle on of developer mode.
4. Now choose load unpacked.
5. choose the repo on your pc.

## Usage
To use the Set Password extension, follow these steps:

1. Click on the Set Password icon in the Chrome toolbar.
2. Enter your password in the "Set password" field.
4. Click on the "Send" button.

## Features
The Set Password extension has the following features:

* The person can set password on chrome so that without him no other user can use that extension.

## Support
If you have any questions or problems with the Set Password extension, please contact the developer at [goravjindal86@gmail.com](goravjindal86@gmail.com).
